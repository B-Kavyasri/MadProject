package com.example.vvit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Bmi extends AppCompatActivity {
    EditText edKg,edFeet,edInc;
    TextView tvDisplay;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);

        edKg=findViewById(R.id.edKg);
        edFeet=findViewById(R.id.edFeet);
        edInc=findViewById(R.id.edInc);

        imageView=findViewById(R.id.imageView);
        tvDisplay=findViewById(R.id.tvDisplay);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String kg=edKg.getText().toString();
                String feet=edFeet.getText().toString();
                String inc=edInc.getText().toString();

                float wKg=Float.parseFloat(kg);
                float wFeet=Float.parseFloat(feet);
                float wInc=Float.parseFloat(inc);

                float height= (float) (wFeet*3048 + wInc*0.0264);

                float bmiIndex= wKg/(wFeet*wInc);

                if(edKg.length()>0 && edFeet.length()>0 && edInc.length()>0){

                    if(bmiIndex>=24){
                        tvDisplay.setText("your Bmi Index:"+bmiIndex+"over weight");
                    }
                    else if(bmiIndex>=18){
                        tvDisplay.setText("your Bmi Index:"+bmiIndex+"Normal weight");
                    }
                    else{
                        tvDisplay.setText("your Bmi Index:"+bmiIndex+"under weight");
                    }




                }
                else {
                    tvDisplay.setText("input all files");
                }

            }
        });
    }

}